---
date: "2016-05-05T21:48:51-07:00"
title: Recursos
---

**Video tutorial:** <https://youtu.be/31EzFKNzObk>

**Libro** : "blogdown: Creating Websites with R Markdown" 

<https://bookdown.org/yihui/blogdown/>

<center>
<img src="https://bookdown.org/yihui/blogdown/images/cover.png" width="200">
<center>




