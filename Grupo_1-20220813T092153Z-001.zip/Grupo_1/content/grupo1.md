---
date: "2016-05-05T21:48:51-07:00"
title: Contacto
---
<center>
<img src="https://desinfeccionelectrostatica.com/wp-content/uploads/2019/06/contacto.png" width="800">
<div style="text-align: justify">

Buen dìa a los lectores , somos estudiantes del 2ªdo ciclo de la carrera de estadística e informática , les invitamos a seguir nuestras redes, para puedan seguir de más cerca nuestros trabajos individuales y grupales, sin más que decir muchas gracias.

**Jhordy Alexander Castro**

-   20210830@lamolina.edu.pe

**Michael Alexis Bañares Gutierrez**

-   20210824\@lamolina.edu.pe

-   GitHub : <https://github.com/MGato24>

**André Benjamín Castillo**

-   20210829@lamolina.edu.pe

**Edwar Frank Carrasco Castañeda**

-   20210827@lamolina.edu.pe

-   GitHub : <https://github.com/Frank2xyz>

**Renato Alonso Canales**

-   20210826@lamolina.edu.pe

![](https://i.ibb.co/b7n6XyP/awa.png) <div/>